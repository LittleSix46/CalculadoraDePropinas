/**
 * 
 */
/**
 * 
 */
module CalculadoraDeMonedas {
	requires java.desktop;
}